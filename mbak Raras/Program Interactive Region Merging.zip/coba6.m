s = [1 1],[2 3];
t = [2 3 4 5 6];
weights = [5 5 5 6 9];
G = graph(double(L),'upper');
plot(G)
